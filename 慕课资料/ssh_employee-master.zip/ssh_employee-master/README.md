# ssh_employee
ssh框架实现的员工信息管理系统
该工程整合了struts2、spring、hibernate三大框架。实现了员工的增删改查以及部门的增删改查。
